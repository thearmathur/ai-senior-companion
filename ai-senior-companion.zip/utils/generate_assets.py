"""
Generates synthetic sample bill image for offline and demo evaluation.
"""
import os
from PIL import Image, ImageDraw

def create_sample_bill_image():
    out_dir = os.path.join(os.path.dirname(__file__), "..", "assets", "sample_bills")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "sample_electricity_bill.png")

    img = Image.new("RGB", (800, 600), color="#F8FAFC")
    draw = ImageDraw.Draw(img)

    # Header banner
    draw.rectangle([(0, 0), (800, 90)], fill="#1B4965")
    draw.text((30, 25), "BSES RAJDHANI POWER LIMITED (BRPL)", fill="#FFFFFF")
    draw.text((30, 55), "ELECTRICITY CONSUMPTION INVOICE - SEPTEMBER 2026", fill="#BAE6FD")

    # Content Box
    draw.rectangle([(30, 110), (770, 560)], outline="#CBD5E1", fill="#FFFFFF", width=2)

    draw.text((60, 140), "Consumer Name  : MR. ANAND SHARMA", fill="#1E293B")
    draw.text((60, 175), "CA Number      : 100458921", fill="#1E293B")
    draw.text((60, 210), "Bill Date      : 10-Sep-2026", fill="#1E293B")
    draw.text((60, 245), "Billing Period : 08-Aug-2026 to 08-Sep-2026", fill="#1E293B")
    draw.text((60, 280), "Units Consumed : 340 Units (kWh)", fill="#1E293B")

    draw.line([(60, 320), (740, 320)], fill="#E2E8F0", width=2)

    draw.text((60, 345), "ENERGY CHARGES BREAKUP:", fill="#1B4965")
    draw.text((60, 375), "Energy Charges (340 Units) : Rs. 2,150.00", fill="#334155")
    draw.text((60, 405), "Fixed Monthly Charges      : Rs.   180.00", fill="#334155")
    draw.text((60, 435), "Electricity Duty (5%)      : Rs.   120.00", fill="#334155")

    draw.line([(60, 470), (740, 470)], fill="#1B4965", width=2)

    draw.text((60, 490), "NET AMOUNT PAYABLE : Rs. 2,450.00", fill="#0F766E")
    draw.text((450, 490), "DUE DATE: 25-SEP-2026", fill="#B91C1C")
    draw.text((60, 530), "Payment Mode: Official BSES App / Bank Netbanking", fill="#64748B")

    img.save(out_path)
    print(f"Sample bill image created at: {out_path}")

if __name__ == "__main__":
    create_sample_bill_image()
