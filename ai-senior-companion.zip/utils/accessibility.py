"""
Accessibility system for AI Senior Companion.
Generates dynamic CSS for senior-friendly font scaling, high-contrast themes,
generous click targets, and readable line spacing.
"""
from typing import Dict
from config.settings import TEXT_SIZES


def get_accessibility_css(text_size: str = "Large", contrast_mode: str = "Standard") -> str:
    """
    Returns custom CSS tailored to senior accessibility preferences.
    """
    size_config = TEXT_SIZES.get(text_size, TEXT_SIZES["Large"])
    body_size = size_config["body"]
    heading_size = size_config["heading"]
    button_size = size_config["button"]
    line_height = size_config["line_height"]

    if contrast_mode == "High Contrast":
        # High Contrast Palette: Deep slate/black background, ultra-crisp white/yellow text, high-visibility borders
        bg_color = "#0B0F19"
        card_bg = "#151C2C"
        text_color = "#FFFFFF"
        subtext_color = "#CBD5E1"
        accent_color = "#FACC15"  # Vibrant contrast yellow
        border_style = "2px solid #FACC15"
        button_bg = "#FACC15"
        button_text = "#000000"
    else:
        # Standard Warm Palette: Gentle off-white background, deep readable charcoal, soft borders
        bg_color = "#F7F9FC"
        card_bg = "#FFFFFF"
        text_color = "#1E293B"
        subtext_color = "#475569"
        accent_color = "#1B4965"
        border_style = "1.5px solid #E2E8F0"
        button_bg = "#1B4965"
        button_text = "#FFFFFF"

    css = f"""
    <style>
    /* Global Base Typography & Spacing */
    html, body, [class*="css"], .stMarkdown, p, div, span, label {{
        font-size: {body_size} !important;
        line-height: {line_height} !important;
        color: {text_color} !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
    }}

    /* Main Container & Background */
    .stApp {{
        background-color: {bg_color} !important;
    }}

    /* Headings */
    h1, h2, h3, h4 {{
        font-size: {heading_size} !important;
        font-weight: 700 !important;
        color: {text_color} !important;
        margin-top: 0.5rem !important;
        margin-bottom: 0.8rem !important;
    }}

    /* Subtext and captions */
    .caption-text, .stCaption {{
        font-size: calc({body_size} - 2px) !important;
        color: {subtext_color} !important;
    }}

    /* Senior-friendly Big Buttons (>48px minimum touch target) */
    .stButton > button {{
        font-size: {button_size} !important;
        font-weight: 600 !important;
        min-height: 52px !important;
        padding: 12px 24px !important;
        border-radius: 12px !important;
        background-color: {button_bg} !important;
        color: {button_text} !important;
        border: {border_style} !important;
        cursor: pointer !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
        transition: transform 0.1s ease, box-shadow 0.1s ease !important;
        width: 100% !important;
        margin: 6px 0 !important;
    }}
    .stButton > button:hover {{
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 10px -1px rgba(0, 0, 0, 0.15) !important;
    }}
    .stButton > button:active {{
        transform: translateY(0) !important;
    }}

    /* Senior Accessible Cards */
    .senior-card {{
        background-color: {card_bg} !important;
        border: {border_style} !important;
        border-radius: 16px !important;
        padding: 24px !important;
        margin-bottom: 20px !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05) !important;
    }}

    /* Risk Badges */
    .badge-high {{
        background-color: #FEE2E2 !important;
        color: #991B1B !important;
        border: 2px solid #EF4444 !important;
        padding: 6px 14px !important;
        border-radius: 9999px !important;
        font-weight: 700 !important;
        display: inline-block !important;
    }}
    .badge-medium {{
        background-color: #FEF3C7 !important;
        color: #92400E !important;
        border: 2px solid #F59E0B !important;
        padding: 6px 14px !important;
        border-radius: 9999px !important;
        font-weight: 700 !important;
        display: inline-block !important;
    }}
    .badge-low {{
        background-color: #DCFCE7 !important;
        color: #166534 !important;
        border: 2px solid #22C55E !important;
        padding: 6px 14px !important;
        border-radius: 9999px !important;
        font-weight: 700 !important;
        display: inline-block !important;
    }}

    /* Inputs (Text areas, selects) */
    .stTextInput input, .stTextArea textarea, .stSelectbox div[data-baseweb="select"] {{
        font-size: {body_size} !important;
        min-height: 48px !important;
        border-radius: 10px !important;
        border: {border_style} !important;
        background-color: {card_bg} !important;
        color: {text_color} !important;
    }}

    /* Hide Streamlit watermark & hamburger menu for uncluttered senior look */
    #MainMenu {{visibility: hidden;}}
    footer {{visibility: hidden;}}
    header {{visibility: hidden;}}
    </style>
    """
    return css
