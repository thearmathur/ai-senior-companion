"""
Validation, JSON extraction, and Intent Detection utilities.
"""
import json
import re
from typing import Dict, Any, Optional


def clean_json_markdown(text: str) -> str:
    """Strips markdown code block fencing from raw model text."""
    text = text.strip()
    # Match ```json ... ``` or ``` ... ```
    match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', text)
    if match:
        return match.group(1).strip()
    return text


def safe_parse_json(text: str, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Safely parses JSON string with fallback default."""
    if default is None:
        default = {}
    cleaned = clean_json_markdown(text)
    try:
        return json.loads(cleaned)
    except Exception:
        # Try finding the first '{' and last '}'
        start = cleaned.find('{')
        end = cleaned.rfind('}')
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(cleaned[start:end+1])
            except Exception:
                pass
        return default


def detect_user_intent(message: str) -> str:
    """
    Classifies user message into high-level intent to connect modules:
    - 'scam': suspicious text, lottery, prize, urgent bank block, fake link
    - 'explain': electricity bill, document, notice, what does this mean
    - 'guided_task': how to pay, how to book, step-by-step, change password
    - 'reminder': remind me, yaad dilana, calendar, appointment
    - 'general': everyday conversation or greeting
    """
    text = message.lower()

    # Scam indicators
    scam_terms = [
        "scam", "fraud", "suspicious", "fake", "lottery", "prize", "won ₹", "won rs", 
        "won 25 lakh", "blocked bank", "account suspended", "kyc expired", "pay fee to claim",
        "अवैध", "धोखा", "लॉटरी", "संदेहास्पद"
    ]
    if any(term in text for term in scam_terms):
        return "scam"

    # Document / Explain indicators
    explain_terms = [
        "bill", "electricity bill", "water bill", "receipt", "document", "prescription",
        "notice", "what does this mean", "explain this", "charges", "बिजली बिल", "रसीद", "दस्तावेज़"
    ]
    if any(term in text for term in explain_terms):
        return "explain"

    # Guided Task indicators
    task_terms = [
        "how do i", "how to", "guide me", "steps to", "book appointment", "change password",
        "pay my", "fill form", "madad", "kaise karein", "तरीका", "कैसे करें"
    ]
    if any(term in text for term in task_terms):
        return "guided_task"

    # Reminder indicators
    reminder_terms = [
        "remind me", "reminder", "set alarm", "medicine time", "remember to",
        "yaad dilana", "दवा का समय", "याद दिलाओ", "कल जाना है"
    ]
    if any(term in text for term in reminder_terms):
        return "reminder"

    return "general"
