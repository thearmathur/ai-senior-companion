"""
Utility script to create a clean zip file for GitHub upload via web UI.
"""
import os
import zipfile

def make_archive():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    zip_path = os.path.join(base_dir, "ai-senior-companion.zip")
    
    exclude_dirs = {"__pycache__", ".pytest_cache", "venv", ".venv"}
    exclude_files = {"powershell.cmd", "senior_companion.db", "ai-senior-companion.zip", ".env"}

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            for file in files:
                if file in exclude_files or file.endswith(".pyc") or file.endswith(".sqlite3"):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, base_dir)
                zipf.write(file_path, arcname)

    print(f"Clean archive created at: {zip_path}")

if __name__ == "__main__":
    make_archive()
