"""
Helper functions: Localization (English & Hindi), date formatters, trusted contact helpers,
and voice speech recognition fallback.
"""
from datetime import datetime
import urllib.parse
from typing import Dict, Any


TRANSLATIONS = {
    "English": {
        "app_title": "AI Senior Companion",
        "tagline": "Your simple, safe and trusted digital companion.",
        "nav_home": "🏠 Home",
        "nav_companion": "🤖 Ask Companion",
        "nav_explain": "📄 Explain Something",
        "nav_scam": "🛡️ Scam Shield",
        "nav_guided": "🧭 Guided Help",
        "nav_reminders": "🔔 My Reminders",
        "nav_my_day": "📅 My Day",
        "nav_trusted": "👥 Trusted Help",
        "nav_settings": "⚙️ Settings",
        "greeting_morning": "Good Morning",
        "greeting_afternoon": "Good Afternoon",
        "greeting_evening": "Good Evening",
        "how_can_i_help": "How can I help you today?",
        "voice_button": "🎤 Tap to Speak",
        "voice_fallback": "Voice input is ready or you can type your request below.",
        "ask_input_placeholder": "Type or speak your question in simple words...",
        "today_heading": "TODAY'S REMINDERS",
        "quick_help": "QUICK ACTIONS",
        "proactive_banner": "PROACTIVE SAFETY & ASSISTANCE",
        "btn_explain": "📄 Explain a Bill or Document",
        "btn_scam": "🛡️ Check a Suspicious Message",
        "btn_guided": "🧭 Step-by-Step Task Guide",
        "btn_reminder": "🔔 Add a New Reminder",
        "done_button": "I've Done This ->",
        "finish_button": "Finish Task",
        "trusted_contact_alert": "This situation may need help from someone you trust.",
        "ask_trusted": "Ask Trusted Person",
        "continue_myself": "Continue Myself",
        "reset_demo": "Reset Demo Data"
    },
    "Hindi": {
        "app_title": "एआई सीनियर साथी (AI Senior Companion)",
        "tagline": "आपका सरल, सुरक्षित और भरोसेमंद डिजिटल साथी।",
        "nav_home": "🏠 मुख्य पृष्ठ (Home)",
        "nav_companion": "🤖 साथी से पूछें (Ask Companion)",
        "nav_explain": "📄 समझाइए (Explain)",
        "nav_scam": "🛡️ धोखा सुरक्षा (Scam Shield)",
        "nav_guided": "🧭 कदम-दर-कदम मदद (Guided Help)",
        "nav_reminders": "🔔 मेरे रिमाइंडर (Reminders)",
        "nav_my_day": "📅 मेरा दिन (My Day)",
        "nav_trusted": "👥 भरोसेमंद संपर्क (Trusted Help)",
        "nav_settings": "⚙️ सेटिंग्स (Settings)",
        "greeting_morning": "सुप्रभात",
        "greeting_afternoon": "नमस्कार",
        "greeting_evening": "शुभ संध्या",
        "how_can_i_help": "आज मैं आपकी क्या सहायता कर सकता हूँ?",
        "voice_button": "🎤 बोलकर पूछें",
        "voice_fallback": "आप बोलकर बता सकते हैं या नीचे लिखकर पूछ सकते हैं।",
        "ask_input_placeholder": "अपना सवाल यहाँ सरल शब्दों में लिखें...",
        "today_heading": "आज के ज़रूरी काम और दवाइयाँ",
        "quick_help": "त्वरित सहायता",
        "proactive_banner": "सुरक्षा और सहायता सुझाव",
        "btn_explain": "📄 कोई बिल या कागज़ समझें",
        "btn_scam": "🛡️ संदिग्ध संदेश की जाँच करें",
        "btn_guided": "🧭 काम करने का सरल तरीका सीखें",
        "btn_reminder": "🔔 नया रिमाइंडर जोड़ें",
        "done_button": "मैंने यह कर लिया ->",
        "finish_button": "काम पूरा हुआ",
        "trusted_contact_alert": "इस मामले में आपको अपने किसी भरोसेमंद परिजन की मदद लेनी चाहिए।",
        "ask_trusted": "भरोसेमंद व्यक्ति से पूछें",
        "continue_myself": "मैं स्वयं करूँगा",
        "reset_demo": "डेमो डेटा रीसेट करें"
    }
}


def t(key: str, language: str = "English") -> str:
    """Retrieves localized UI text string."""
    lang_dict = TRANSLATIONS.get(language, TRANSLATIONS["English"])
    return lang_dict.get(key, TRANSLATIONS["English"].get(key, key))


def format_friendly_date(date_str: str, language: str = "English") -> str:
    """Formats YYYY-MM-DD into warm senior-friendly date string."""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        if language == "Hindi":
            months_hi = ["जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"]
            days_hi = ["सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार", "रविवार"]
            return f"{days_hi[dt.weekday()]}, {dt.day} {months_hi[dt.month - 1]} {dt.year}"
        return dt.strftime("%A, %d %B %Y")
    except Exception:
        return date_str


def get_greeting(user_name: str, language: str = "English") -> str:
    """Generates time-of-day greeting."""
    hour = datetime.now().hour
    if hour < 12:
        period = "greeting_morning"
    elif hour < 17:
        period = "greeting_afternoon"
    else:
        period = "greeting_evening"
    
    greeting = t(period, language)
    return f"{greeting}, {user_name} 👋"


def generate_trusted_contact_url(phone: str, message: str) -> str:
    """Creates a prefilled WhatsApp Web / App share URL."""
    clean_phone = "".join(filter(str.isdigit, phone))
    encoded_msg = urllib.parse.quote(message)
    return f"https://wa.me/{clean_phone}?text={encoded_msg}"
