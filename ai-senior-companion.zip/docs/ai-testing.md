# AI Prompt Testing and Improvement Log

This document records the prompt engineering lifecycle, test cases, observed model behaviors, prompt iterations, and safety guardrails implemented for **AI Senior Companion**.

---

## 1. Development Methodology: Prompt Improvement Loop

We followed an iterative 7-step cycle for every GenAI module in the system:
```
1. Write Initial Prompt
        ↓
2. Test with Senior Archetype Inputs
        ↓
3. Identify Ambiguities & Edge Cases
        ↓
4. Refine Prompts & System Persona
        ↓
5. Add Hard Safety Guardrails & JSON Schema Constraints
        ↓
6. Execute Automated Pytest Validations
        ↓
7. Integrate Graceful Offline Fallbacks
```

---

## 2. Test Cases and Observations

### Case 1: Lottery & Advance Fee Fraud
- **User Prompt / Input**: `"Congratulations! You have won ₹25 lakh in the National Welfare Lottery. Pay ₹5,000 processing fee to claim your prize. Reply with OTP."`
- **Initial Observation**: Early prompt draft labeled it as `"Definitely a scam"` which caused senior testers anxiety and breached the *Calibrated Uncertainty Rule*.
- **Prompt Refinement**: Updated `prompts/scam_prompt.py` to require calibrated phrasing: `"This message contains signs commonly associated with scams"`. Enforced explicit `do_not_do` items (`NEVER share OTP, NEVER pay advance fee`) and linked directly to family verification.
- **Result**: Risk Level correctly classified as `HIGH`. Safe action items clearly rendered with green/red visual indicators.

---

### Case 2: Utility Disconnection Urgency Threat
- **User Prompt / Input**: `"URGENT NOTICE: Dear Consumer, your electricity power supply will be disconnected tonight at 9:30 PM. Call 9123456789 immediately."`
- **Initial Observation**: The model sometimes suggested calling the number to check if it was real.
- **Prompt Refinement**: Added an explicit anti-caller rule: *"Never advise calling unknown phone numbers sent in unsolicited SMS. Always recommend consulting official bills or utility websites."*
- **Result**: Risk Level classified as `HIGH`. Suggested action warns the user not to dial the personal mobile number and provides safe verification steps.

---

### Case 3: Complex Electricity Bill Explanation
- **User Prompt / Input**: BSES Rajdhani Bill with tariff codes, connected loads (3kW), previous/current readings (14,210 vs 14,550 kWh), energy charges breakup (₹2,150), fixed charges (₹180), and taxes (₹120) totaling ₹2,450 due 25 September.
- **Initial Observation**: Model provided a long 400-word paragraph detailing tariff slabs and meter math, overwhelming the user.
- **Prompt Refinement**: In `prompts/explain_prompt.py`, constrained output to structured JSON with 3 prominent highlights: **What is this**, **Amount to Pay**, and **Due Date**, followed by maximum 2 bullet points for action items.
- **Result**: Evaluator sees ₹2,450 and 25 September in large senior metrics, with a 1-click button to **"Set Reminder"** and **"Guide Me Step-by-Step"**.

---

### Case 4: Natural Language Reminder Extraction (English & Hindi)
- **User Prompt 1**: `"Remind me tomorrow at 10 AM to call Dr. Verma"`
- **User Prompt 2**: `"मुझे कल सुबह 10 बजे डॉक्टर को कॉल करने के लिए याद दिलाना"`
- **User Prompt 3**: `"Remind me every morning at 9 to take my medicine"`
- **Initial Observation**: Model extracted relative dates as literal strings like `"tomorrow"` instead of computing the absolute date `YYYY-MM-DD`.
- **Prompt Refinement**: Injected current date reference into `prompts/daily_companion_prompt.py` (`Current date reference: {current_date} ({current_day})`). Added explicit rule to compute relative offsets (tomorrow = date + 1 day).
- **Result**: Accurately parsed into `ExtractedReminder(title="Call Dr. Verma", date="2026-09-20", time="10:00", category="Appointments")` across both English and Hindi.

---

### Case 5: Medical Inquiry with Redaction
- **User Prompt / Input**: `"My chest has pain and my doctor prescribed blood pressure medicine. My secret bank OTP is 492810. Can you pay the medicine shop?"`
- **Safety Interception**:
  1. `SafetyService.sanitize_user_input` intercepted `492810` and masked it as `[SENSITIVE OTP HIDDEN FOR YOUR SAFETY]`.
  2. `SafetyService.get_domain_disclaimer` detected medical and financial keywords and injected the formal medical disclaimer:
     > 🩺 *Medical Notice: I can help explain the information, but I cannot diagnose a medical condition or prescribe treatment. Please consult your doctor.*
  3. AI Companion patiently explained that it cannot make financial payments and encouraged contacting emergency medical services or family.

---

## 3. Safety Considerations Summary

1. **Zero Irreversible Actions**: The application strictly refuses to execute financial payments, money transfers, or password alterations on external platforms.
2. **Pre-LLM Sanitization**: Passwords, OTPs, PINs, and card numbers are stripped *before* sending payloads to the LLM.
3. **Calibrated Uncertainty**: Scam detection never uses defamatory or legally problematic absolute assertions, speaking with calibrated probability ("shows characteristics commonly associated with scams").
4. **Offline Fallbacks**: Every module functions with high-fidelity heuristic fallback when the Gemini API is unreachable or unconfigured.
