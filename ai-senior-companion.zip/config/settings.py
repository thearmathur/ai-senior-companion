"""
Application configuration and settings management for AI Senior Companion.
Safely retrieves secrets and provides senior-friendly sensible defaults.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Base Directory paths
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "senior_companion.db"
ASSETS_DIR = BASE_DIR / "assets"

# Load local .env if available
load_dotenv(BASE_DIR / ".env")

def get_gemini_api_key() -> str:
    """
    Safely retrieve Gemini API Key from environment variables or Streamlit secrets.
    Does not crash if missing; returns empty string for graceful UI handling.
    """
    api_key = os.getenv("GEMINI_API_KEY", "")
    if not api_key:
        try:
            import streamlit as st
            if hasattr(st, "secrets") and "GEMINI_API_KEY" in st.secrets:
                api_key = st.secrets["GEMINI_API_KEY"]
        except Exception:
            pass
    return api_key.strip()

# Default Gemini model
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

# Application Metadata
APP_NAME = "AI Senior Companion"
APP_TAGLINE = "Your simple, safe and trusted digital companion."
APP_VERSION = "1.0.0"

# Accessibility Defaults
DEFAULT_TEXT_SIZE = "Large"  # Standard, Large, Extra Large
DEFAULT_CONTRAST = "Standard"  # Standard, High Contrast
DEFAULT_LANGUAGE = "English"  # English, Hindi
DEFAULT_VOICE = True

# Senior-friendly visual configurations
TEXT_SIZES = {
    "Standard": {"body": "18px", "heading": "24px", "button": "18px", "line_height": "1.6"},
    "Large": {"body": "22px", "heading": "28px", "button": "22px", "line_height": "1.7"},
    "Extra Large": {"body": "26px", "heading": "34px", "button": "26px", "line_height": "1.8"}
}

# Predefined categories for senior reminders
REMINDER_CATEGORIES = [
    "Medicine",
    "Bills",
    "Appointments",
    "Personal",
    "Important"
]
