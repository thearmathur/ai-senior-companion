"""
Database manager for SQLite persistence in AI Senior Companion.
Handles initialization, migrations, seeding demo records, and thread-safe operations.
"""
import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from config.settings import DB_PATH
from database.schema import ALL_SCHEMAS


def get_connection() -> sqlite3.Connection:
    """Returns a SQLite connection with Row factory enabled."""
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initializes the database schema if tables do not exist."""
    with get_connection() as conn:
        cursor = conn.cursor()
        for schema_sql in ALL_SCHEMAS:
            cursor.execute(schema_sql)
        conn.commit()


def seed_demo_data():
    """Seeds rich demo data for Mr. Sharma if no user exists."""
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        count = cursor.fetchone()[0]
        if count > 0:
            return  # Already seeded

        # Insert default user
        cursor.execute(
            "INSERT INTO users (name, email) VALUES (?, ?)",
            ("Mr. Sharma", "sharma.senior@example.com")
        )
        user_id = cursor.lastrowid

        # Insert preferences (Large font, standard contrast, English)
        cursor.execute(
            """
            INSERT INTO preferences (user_id, text_size, contrast_mode, language, voice_enabled)
            VALUES (?, ?, ?, ?, ?)
            """,
            (user_id, "Large", "Standard", "English", 1)
        )

        # Calculate relative dates for today, tomorrow, and 2 days out
        today = datetime.now().date()
        tomorrow = today + timedelta(days=1)
        in_two_days = today + timedelta(days=2)

        # Seed realistic senior reminders
        demo_reminders = [
            (user_id, "Take Morning Blood Pressure Medicine (Amlodipine 5mg)", "Medicine", today.strftime("%Y-%m-%d"), "09:00", "Daily", "PENDING", "Take after a light breakfast with a glass of water."),
            (user_id, "Electricity Bill Due (BSES Rajdhani - ₹2,450)", "Bills", in_two_days.strftime("%Y-%m-%d"), "18:00", "None", "PENDING", "Consumer No: 100458921. Keep payment receipt safe."),
            (user_id, "Routine Health Check-up with Dr. Verma", "Appointments", tomorrow.strftime("%Y-%m-%d"), "11:00", "None", "PENDING", "City Hospital Clinic Room 204. Carry previous sugar reports.")
        ]
        cursor.executemany(
            """
            INSERT INTO reminders (user_id, title, category, due_date, due_time, recurrence, status, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            demo_reminders
        )

        # Seed Trusted Contact (e.g. Son)
        cursor.execute(
            """
            INSERT INTO trusted_contacts (user_id, name, relationship, phone, email, notes)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (user_id, "Aarav Sharma", "Son", "+91 98765 43210", "aarav.sharma@example.com", "Lives nearby in sector 4. Reach out for any urgent bill or medical assistance.")
        )
        conn.commit()


def reset_demo_data():
    """Wipes all tables and reseeds fresh demo data for evaluators."""
    with get_connection() as conn:
        cursor = conn.cursor()
        tables = ["conversation_sessions", "trusted_contacts", "reminders", "preferences", "users"]
        for table in tables:
            cursor.execute(f"DROP TABLE IF EXISTS {table}")
        conn.commit()
    seed_demo_data()


def get_default_user() -> Dict[str, Any]:
    """Retrieves or creates the primary senior user."""
    seed_demo_data()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users ORDER BY id ASC LIMIT 1")
        row = cursor.fetchone()
        return dict(row) if row else {"id": 1, "name": "Mr. Sharma"}


def get_user_preferences(user_id: int) -> Dict[str, Any]:
    """Returns accessibility and localization preferences for user."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM preferences WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        if row:
            return dict(row)
        return {
            "user_id": user_id,
            "text_size": "Large",
            "contrast_mode": "Standard",
            "language": "English",
            "voice_enabled": 1
        }


def update_user_preferences(user_id: int, text_size: str, contrast_mode: str, language: str, voice_enabled: int):
    """Updates user accessibility and language preferences."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO preferences (user_id, text_size, contrast_mode, language, voice_enabled, updated_at)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(user_id) DO UPDATE SET
                text_size = excluded.text_size,
                contrast_mode = excluded.contrast_mode,
                language = excluded.language,
                voice_enabled = excluded.voice_enabled,
                updated_at = CURRENT_TIMESTAMP
            """,
            (user_id, text_size, contrast_mode, language, voice_enabled)
        )
        conn.commit()


def add_reminder(user_id: int, title: str, category: str, due_date: str, due_time: str = "09:00", recurrence: str = "None", notes: str = "") -> int:
    """Inserts a new reminder record."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO reminders (user_id, title, category, due_date, due_time, recurrence, status, notes)
            VALUES (?, ?, ?, ?, ?, ?, 'PENDING', ?)
            """,
            (user_id, title, category, due_date, due_time, recurrence, notes)
        )
        conn.commit()
        return cursor.lastrowid


def get_reminders(user_id: int, status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    """Fetches reminders for a user, optionally filtered by status."""
    with get_connection() as conn:
        cursor = conn.cursor()
        if status_filter:
            cursor.execute(
                "SELECT * FROM reminders WHERE user_id = ? AND status = ? ORDER BY due_date ASC, due_time ASC",
                (user_id, status_filter)
            )
        else:
            cursor.execute(
                "SELECT * FROM reminders WHERE user_id = ? ORDER BY due_date ASC, due_time ASC",
                (user_id,)
            )
        rows = cursor.fetchall()
        return [dict(r) for r in rows]


def update_reminder_status(reminder_id: int, status: str):
    """Updates reminder status (e.g. COMPLETED or PENDING)."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE reminders SET status = ? WHERE id = ?", (status, reminder_id))
        conn.commit()


def delete_reminder(reminder_id: int):
    """Deletes a reminder record."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
        conn.commit()


def get_trusted_contacts(user_id: int) -> List[Dict[str, Any]]:
    """Returns list of trusted family/caregiver contacts."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM trusted_contacts WHERE user_id = ? ORDER BY id ASC", (user_id,))
        rows = cursor.fetchall()
        return [dict(r) for r in rows]


def add_trusted_contact(user_id: int, name: str, relationship: str, phone: str, email: str = "", notes: str = "") -> int:
    """Adds a new trusted contact."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO trusted_contacts (user_id, name, relationship, phone, email, notes)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (user_id, name, relationship, phone, email, notes)
        )
        conn.commit()
        return cursor.lastrowid


def delete_trusted_contact(contact_id: int):
    """Deletes a trusted contact."""
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM trusted_contacts WHERE id = ?", (contact_id,))
        conn.commit()
