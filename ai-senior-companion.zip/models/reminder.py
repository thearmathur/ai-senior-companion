"""
Pydantic data models for Reminders and Natural Language Reminder Extraction.
"""
from typing import Optional
from pydantic import BaseModel, Field


class ReminderItem(BaseModel):
    id: Optional[int] = None
    user_id: int = 1
    title: str
    category: str = Field(default="Important", description="Medicine, Bills, Appointments, Personal, Important")
    due_date: str = Field(description="YYYY-MM-DD format")
    due_time: str = Field(default="09:00", description="HH:MM 24-hour format")
    recurrence: str = Field(default="None", description="None, Daily, Weekly, Monthly")
    status: str = Field(default="PENDING", description="PENDING, COMPLETED")
    notes: Optional[str] = ""


class ExtractedReminder(BaseModel):
    title: str
    category: str = "Important"
    date: str = Field(description="YYYY-MM-DD format or specific date")
    time: str = Field(default="09:00", description="HH:MM format")
    recurrence: str = "None"
    confirmation_required: bool = True
    clarification_question: Optional[str] = None
