"""
Pydantic data models for User and Preferences.
"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class UserPreferences(BaseModel):
    user_id: int = 1
    text_size: str = Field(default="Large", description="Standard, Large, Extra Large")
    contrast_mode: str = Field(default="Standard", description="Standard, High Contrast")
    language: str = Field(default="English", description="English, Hindi")
    voice_enabled: bool = True
    updated_at: Optional[datetime] = None


class UserProfile(BaseModel):
    id: int = 1
    name: str = "Mr. Sharma"
    email: Optional[str] = ""
    preferences: Optional[UserPreferences] = None
    created_at: Optional[datetime] = None


class TrustedContact(BaseModel):
    id: Optional[int] = None
    user_id: int = 1
    name: str
    relationship: str
    phone: str
    email: Optional[str] = ""
    notes: Optional[str] = ""
