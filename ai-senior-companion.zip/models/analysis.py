"""
Pydantic data models for Scam Analysis, Document Explanation, and Guided Tasks.
"""
from typing import List, Optional
from pydantic import BaseModel, Field


class ScamAnalysis(BaseModel):
    risk_level: str = Field(description="LOW, MEDIUM, HIGH, or UNKNOWN")
    summary: str = Field(description="Clear explanation in simple everyday language")
    warning_signs: List[str] = Field(default_factory=list, description="List of detected red flags")
    do_not_do: List[str] = Field(default_factory=list, description="Concrete actions to avoid (e.g. don't share OTP)")
    safe_next_steps: List[str] = Field(default_factory=list, description="Safe and recommended next actions")
    confidence: str = Field(default="medium", description="low, medium, high")


class DocumentExplanation(BaseModel):
    document_type: str = Field(description="Human readable document type (e.g. Electricity Bill)")
    simple_summary: str = Field(description="Plain English/Hindi summary without technical jargon")
    amount_to_pay: Optional[str] = Field(default=None, description="Amount with currency symbol if applicable")
    due_date: Optional[str] = Field(default=None, description="Due date if applicable")
    provider_or_sender: Optional[str] = Field(default=None, description="Name of company, utility, or bank")
    important_details: List[str] = Field(default_factory=list, description="Key facts the senior should know")
    what_you_need_to_do: List[str] = Field(default_factory=list, description="Clear, bite-sized instructions")
    safety_warning: Optional[str] = Field(default=None, description="Cautionary note if any")
    suggested_action: Optional[str] = Field(default="set_reminder", description="Suggested action: set_reminder, guide_payment, or none")


class GuidedStep(BaseModel):
    step_number: int
    total_steps: int
    title: str
    description: str
    helpful_tip: Optional[str] = None
    safety_reminder: Optional[str] = None
    action_button_label: str = "I've Done This ->"


class GuidedTask(BaseModel):
    task_name: str
    total_steps: int
    steps: List[GuidedStep]
    disclaimer: str = "This is a guidance system. No actual financial or medical actions are performed."
