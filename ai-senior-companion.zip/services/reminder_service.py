"""
Reminder and Proactive Scheduling Service.
Parses natural language requests, handles recurring schedules, and synthesizes daily briefings.
"""
from datetime import datetime, timedelta
import logging
import re
from typing import Dict, Any, List, Optional
from models.reminder import ExtractedReminder, ReminderItem
from prompts.daily_companion_prompt import (
    get_reminder_extraction_prompt,
    get_proactive_briefing_prompt
)
from database.database import (
    add_reminder,
    get_reminders,
    update_reminder_status,
    delete_reminder
)
from services.gemini_service import gemini_service

logger = logging.getLogger(__name__)


class ReminderService:
    def extract_reminder(self, user_text: str, language: str = "English") -> ExtractedReminder:
        """
        Parses natural language text into a structured ExtractedReminder object.
        """
        today = datetime.now().date()
        today_str = today.strftime("%Y-%m-%d")
        day_str = today.strftime("%A")

        fallback_data = self._heuristic_extract(user_text, today)

        if gemini_service.is_configured():
            try:
                prompt = get_reminder_extraction_prompt(today_str, day_str, language)
                full_prompt = f"{prompt}\n\nUser request: \"{user_text}\""
                parsed = gemini_service.generate_structured_json(full_prompt, default_fallback=fallback_data)
                if parsed:
                    return ExtractedReminder(**parsed)
            except Exception as e:
                logger.error(f"Error calling Gemini for reminder extraction: {e}")

        return ExtractedReminder(**fallback_data)

    def _heuristic_extract(self, text: str, today: datetime.date) -> dict:
        """Rule-based extractor for reliable offline and demo execution."""
        lower = text.lower()
        title = text.strip()
        category = "Important"
        target_date = today
        time_str = "09:00"
        recurrence = "None"

        # Category heuristics
        if any(w in lower for w in ["medicine", "tablet", "pill", "bp", "sugar", "दवा"]):
            category = "Medicine"
            if "medicine" not in title.lower() and "दवा" not in title:
                title = f"Take Medicine: {title}"
        elif any(w in lower for w in ["bill", "electricity", "water", "phone", "recharge", "बिल"]):
            category = "Bills"
        elif any(w in lower for w in ["doctor", "hospital", "clinic", "checkup", "appointment", "डॉक्टर"]):
            category = "Appointments"
        elif any(w in lower for w in ["call", "son", "daughter", "friend", "birthday", "फोन"]):
            category = "Personal"

        # Date heuristics
        if "tomorrow" in lower or "kal" in lower or "कल" in lower:
            target_date = today + timedelta(days=1)
        elif "in 2 days" in lower or "parson" in lower:
            target_date = today + timedelta(days=2)
        elif "today" in lower or "aaj" in lower or "आज" in lower or "tonight" in lower:
            target_date = today

        # Search for specific day / month e.g. "25 september"
        month_match = re.search(r'(\d{1,2})(?:st|nd|rd|th)?\s+(january|february|march|april|may|june|july|august|september|october|november|december)', lower)
        if month_match:
            day_num = int(month_match.group(1))
            month_name = month_match.group(2).capitalize()
            try:
                parsed_dt = datetime.strptime(f"{day_num} {month_name} {today.year}", "%d %B %Y")
                target_date = parsed_dt.date()
            except Exception:
                pass

        # Time heuristics
        time_match = re.search(r'(\d{1,2})(?::(\d{2}))?\s*(am|pm)?', lower)
        if "at" in lower or "every morning at" in lower:
            t_match = re.search(r'at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?', lower)
            if t_match:
                hr = int(t_match.group(1))
                mn = int(t_match.group(2)) if t_match.group(2) else 0
                meridiem = (t_match.group(3) or "").lower()
                if meridiem == "pm" and hr < 12:
                    hr += 12
                elif meridiem == "am" and hr == 12:
                    hr = 0
                time_str = f"{hr:02d}:{mn:02d}"

        # Recurrence heuristics
        if "every day" in lower or "daily" in lower or "every morning" in lower or "रोज" in lower or "प्रतिदिन" in lower:
            recurrence = "Daily"
        elif "every week" in lower or "weekly" in lower:
            recurrence = "Weekly"

        return {
            "title": title,
            "category": category,
            "date": target_date.strftime("%Y-%m-%d"),
            "time": time_str,
            "recurrence": recurrence,
            "confirmation_required": True,
            "clarification_question": None
        }

    def get_categorized_reminders(self, user_id: int) -> Dict[str, List[Dict[str, Any]]]:
        """
        Organizes all reminders into 'today', 'upcoming', and 'completed'.
        """
        all_reminders = get_reminders(user_id)
        today_str = datetime.now().strftime("%Y-%m-%d")

        categorized = {
            "today": [],
            "upcoming": [],
            "completed": []
        }

        for rem in all_reminders:
            if rem["status"] == "COMPLETED":
                categorized["completed"].append(rem)
            elif rem["due_date"] <= today_str or rem["recurrence"] == "Daily":
                categorized["today"].append(rem)
            else:
                categorized["upcoming"].append(rem)

        return categorized

    def generate_proactive_briefing(self, user_name: str, user_id: int, language: str = "English") -> str:
        """
        Generates daily morning check-in and proactive nudges for 'My Day'.
        """
        today_str = datetime.now().strftime("%A, %d %B %Y")
        categorized = self.get_categorized_reminders(user_id)
        today_items = categorized["today"]
        upcoming_items = categorized["upcoming"]

        summary_lines = []
        for it in today_items:
            summary_lines.append(f"- [Today {it['due_time']}] ({it['category']}) {it['title']}")
        for it in upcoming_items[:2]:
            summary_lines.append(f"- [Upcoming on {it['due_date']}] ({it['category']}) {it['title']}")

        reminders_text = "\n".join(summary_lines) if summary_lines else "No immediate reminders scheduled."

        is_hindi = language.lower() == "hindi"

        if gemini_service.is_configured():
            try:
                prompt = get_proactive_briefing_prompt(user_name, today_str, reminders_text, language)
                res = gemini_service.generate_chat_response([{"role": "user", "content": prompt}], user_name, language)
                if res and res["text"]:
                    return res["text"]
            except Exception as e:
                logger.warning(f"Failed to generate dynamic briefing: {e}")

        # High quality calm fallback
        if is_hindi:
            msg = f"**सुप्रभात, {user_name}! 🙏**\n\n"
            msg += f"आज {today_str} है। आपका दिन सुखद और स्वस्थ रहे।\n\n"
            if today_items:
                msg += f"**आज के मुख्य कार्य ({len(today_items)}):**\n"
                for it in today_items:
                    msg += f"• ⏰ **{it['due_time']}** - {it['title']}\n"
            else:
                msg += "आज आपके लिए कोई जरूरी काम दर्ज नहीं है। आप निश्चिंत होकर आराम कर सकते हैं।\n"
            if upcoming_items:
                next_item = upcoming_items[0]
                msg += f"\n💡 **आगामी सुझाव:** आपका '{next_item['title']}' ({next_item['due_date']}) आने वाला है। जब भी आप चाहें, मैं इसमें आपकी मदद कर सकता हूँ।"
            return msg

        msg = f"**Good Morning, {user_name}! ☀️**\n\n"
        msg += f"Today is {today_str}. Here is your gentle plan for today:\n\n"
        if today_items:
            msg += f"**Important for Today ({len(today_items)}):**\n"
            for it in today_items:
                msg += f"• ⏰ **{it['due_time']}** — {it['title']}\n"
        else:
            msg += "You have no pressing reminders for today. Enjoy a relaxed, peaceful morning.\n"
        if upcoming_items:
            next_item = upcoming_items[0]
            msg += f"\n💡 **Helpful Proactive Tip:** Your '{next_item['title']}' is due on {next_item['due_date']}. Whenever you are ready, I can guide you through reviewing or paying it step-by-step."
        return msg


reminder_service = ReminderService()
