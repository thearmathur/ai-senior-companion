"""
Guided Help Service for AI Senior Companion ("Guided Help").
Breaks complex digital and administrative tasks into bite-sized sequential steps with checkpoints.
"""
import logging
from typing import Dict, Any, List
from models.analysis import GuidedTask, GuidedStep
from prompts.guided_task_prompt import get_guided_task_prompt
from services.gemini_service import gemini_service

logger = logging.getLogger(__name__)

# Predefined high-quality senior task templates
PREDEFINED_TASKS: Dict[str, Dict[str, Any]] = {
    "Pay an electricity bill": {
        "task_name": "Pay an electricity bill",
        "total_steps": 4,
        "disclaimer": "This is a guidance system. No actual financial payments are executed here.",
        "steps": [
            {
                "step_number": 1,
                "total_steps": 4,
                "title": "Find your Electricity Provider and Consumer Number",
                "description": "Locate your paper bill or previous SMS. Look for your Consumer Account (CA) number at the top-right corner.",
                "helpful_tip": "For example, in Delhi it is BSES (9-digit CA number), in Mumbai it is Adani/Tata Power.",
                "safety_reminder": "Never pay directly into an individual's personal UPI ID or mobile number.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 2,
                "total_steps": 4,
                "title": "Open the Official App or Website",
                "description": "Open your official provider app (e.g., BSES app) or your verified banking app (e.g., BHIM, Google Pay, or SBI Netbanking under 'Bill Pay').",
                "helpful_tip": "Make sure you see the verified green tick or official lock icon on the website address.",
                "safety_reminder": "Do not search random numbers on Google; search results can contain fraudulent support numbers.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 3,
                "total_steps": 4,
                "title": "Enter your Consumer Number and Check the Bill",
                "description": "Type your CA number. The screen will automatically fetch the exact amount due and your name. Verify that the name and amount match your paper bill.",
                "helpful_tip": "If the name shown is not yours, double-check the consumer digits before proceeding.",
                "safety_reminder": "Confirm the bill amount before clicking any payment button.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 4,
                "total_steps": 4,
                "title": "Complete Payment & Save the Receipt",
                "description": "Select your preferred payment method (Netbanking or UPI), enter your secret UPI PIN only on the official bank PIN screen, and take a screenshot of the receipt.",
                "helpful_tip": "Your payment receipt number is proof of payment. Save it or write it down.",
                "safety_reminder": "Remember: entering your UPI PIN always deducts money; you never enter a PIN to receive money.",
                "action_button_label": "Finish Task"
            }
        ]
    },
    "Book a doctor appointment": {
        "task_name": "Book a doctor appointment",
        "total_steps": 4,
        "disclaimer": "This is a guidance system. No actual hospital bookings are made here.",
        "steps": [
            {
                "step_number": 1,
                "total_steps": 4,
                "title": "Choose your Doctor and Clinic",
                "description": "Decide on the specialist you wish to consult (e.g., Cardiologist, Eye Specialist, or General Physician) and note their clinic location.",
                "helpful_tip": "If this is a follow-up, look at your previous prescription slip for the doctor's name.",
                "safety_reminder": "Only use recognized portals (like Practo, Apollo 24/7, Max, or official hospital desks).",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 2,
                "total_steps": 4,
                "title": "Select a Date and Morning Time Slot",
                "description": "Choose a date when you can travel comfortably. Morning slots between 10 AM and 12 PM are usually best for senior consultations.",
                "helpful_tip": "Allow yourself extra travel time so you never feel rushed.",
                "safety_reminder": "Never share your Aadhaar OTP or bank details simply to browse doctor appointment slots.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 3,
                "total_steps": 4,
                "title": "Prepare your Previous Medical Reports",
                "description": "Gather your recent blood tests, sugar readings, blood pressure log, and current list of medicines in a small folder.",
                "helpful_tip": "Doctors appreciate having previous discharge summaries and prescription dates in chronological order.",
                "safety_reminder": "Do not take new medications before consulting your doctor.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 4,
                "total_steps": 4,
                "title": "Confirm Booking and Set a Reminder",
                "description": "Review the doctor's room number and appointment time, confirm the booking, and add it to your reminders in this app.",
                "helpful_tip": "You can tap 'Set Reminder' in this app so I remind you tomorrow morning.",
                "safety_reminder": "Keep the hospital reception helpline number saved in your phone.",
                "action_button_label": "Finish Task"
            }
        ]
    },
    "Change a password safely": {
        "task_name": "Change a password safely",
        "total_steps": 3,
        "disclaimer": "This is a guidance system. Never share your password with anyone, including this app.",
        "steps": [
            {
                "step_number": 1,
                "total_steps": 3,
                "title": "Open Account Security Settings",
                "description": "Go to the official app or website (e.g. Gmail, WhatsApp, or Bank), tap 'Settings', then tap 'Security' or 'Account'.",
                "helpful_tip": "Look for a gear icon ⚙️ or your profile photo in the top corner.",
                "safety_reminder": "Always make sure you are inside the real app, not clicking a password link received via SMS.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 2,
                "total_steps": 3,
                "title": "Create a Strong, Memorable Password",
                "description": "Think of a passphrase combining 3 everyday words you easily remember, plus a number and a symbol (e.g. BlueSky!2026).",
                "helpful_tip": "Do not use your birth year or simple sequences like 123456.",
                "safety_reminder": "Write your new password in a private notebook at home; never send it in an email or chat.",
                "action_button_label": "I've Done This ->"
            },
            {
                "step_number": 3,
                "total_steps": 3,
                "title": "Save and Update on your Device",
                "description": "Type the new password carefully, re-enter it to confirm, and tap 'Save Changes'.",
                "helpful_tip": "If your phone asks 'Save password in Keychain/Google Password Manager?', tap Yes for easy automatic fill next time.",
                "safety_reminder": "No official bank representative will ever ask you to read your password to them.",
                "action_button_label": "Finish Task"
            }
        ]
    }
}


class GuidedService:
    def get_task(self, task_name: str, language: str = "English") -> GuidedTask:
        """
        Retrieves guided task steps, from predefined template or dynamic Gemini generation.
        """
        is_hindi = language.lower() == "hindi"

        # Check if matched in predefined templates
        for key, template in PREDEFINED_TASKS.items():
            if key.lower() in task_name.lower() or task_name.lower() in key.lower():
                return self._localize_task(template, is_hindi)

        # Dynamic generation via Gemini
        if gemini_service.is_configured():
            try:
                prompt = get_guided_task_prompt(task_name, language)
                parsed = gemini_service.generate_structured_json(prompt)
                if parsed and "steps" in parsed:
                    return GuidedTask(**parsed)
            except Exception as e:
                logger.error(f"Error generating dynamic guided task: {e}")

        # Fallback default generic guided task
        default_template = PREDEFINED_TASKS["Pay an electricity bill"]
        return self._localize_task(default_template, is_hindi)

    def _localize_task(self, template: Dict[str, Any], is_hindi: bool) -> GuidedTask:
        """Converts template to Hindi if requested, otherwise returns standard English."""
        if not is_hindi:
            return GuidedTask(**template)

        # Localized Hindi version of templates
        task_name = template["task_name"]
        if "electricity" in task_name.lower():
            return GuidedTask(
                task_name="बिजली का बिल जमा करने की विधि",
                total_steps=4,
                disclaimer="यह एक मार्गदर्शन प्रणाली है। यहाँ कोई वास्तविक वित्तीय लेन-देन नहीं होता।",
                steps=[
                    GuidedStep(
                        step_number=1,
                        total_steps=4,
                        title="उपभोक्ता संख्या (CA Number) निकालें",
                        description="अपने पुराने बिल या एसएमएस से अपनी 9 या 10 अंकों की उपभोक्ता संख्या (Consumer Number) देखें। यह बिल के ऊपरी हिस्से पर लिखी होती है।",
                        helpful_tip="दिल्ली में यह BSES या Tata Power CA Number कहलाता है।",
                        safety_reminder="किसी भी अनजान व्यक्ति के निजी मोबाइल नंबर या व्यक्तिगत UPI पर पैसे न भेजें।",
                        action_button_label="मैंने यह कर लिया ->"
                    ),
                    GuidedStep(
                        step_number=2,
                        total_steps=4,
                        title="आधिकारिक ऐप या वेबसाइट खोलें",
                        description="अपने बिजली बोर्ड का आधिकारिक ऐप या अपने बैंक का सुरक्षित ऐप (जैसे Google Pay, PhonePe या BHIM) खोलें और 'Electricity' चुनें।",
                        helpful_tip="हमेशा सुनिश्चित करें कि कंपनी का नाम सही चुना गया है।",
                        safety_reminder="गूगल पर कस्टमर केयर नंबर न खोजें; वहाँ फर्जी नंबर हो सकते हैं।",
                        action_button_label="मैंने यह कर लिया ->"
                    ),
                    GuidedStep(
                        step_number=3,
                        total_steps=4,
                        title="उपभोक्ता संख्या भरें और बिल राशि मिलाएँ",
                        description="अपनी उपभोक्ता संख्या दर्ज करें। स्क्रीन पर आपके नाम और बिल की बकाया राशि दिखेगी। इसे अपने कागजी बिल से मिला लें।",
                        helpful_tip="यदि नाम आपका न दिखे, तो संख्या दोबारा जाँचें।",
                        safety_reminder="रुपये देने से पहले राशि और नाम की पुष्टि अवश्य करें।",
                        action_button_label="मैंने यह कर लिया ->"
                    ),
                    GuidedStep(
                        step_number=4,
                        total_steps=4,
                        title="भुगतान करें और रसीद सुरक्षित रखें",
                        description="भुगतान का तरीका चुनें, अपना गुप्त यूपीआई पिन केवल अधिकृत बैंक पिन स्क्रीन पर ही दर्ज करें, और रसीद का स्क्रीनशॉट ले लें।",
                        helpful_tip="लेन-देन संदर्भ संख्या (Transaction Reference) को संभाल कर रखें।",
                        safety_reminder="याद रखें: यूपीआई पिन केवल पैसे कटवाने के लिए डाला जाता है, पैसे प्राप्त करने के लिए नहीं।",
                        action_button_label="काम पूरा हुआ"
                    )
                ]
            )

        return GuidedTask(**template)


guided_service = GuidedService()
