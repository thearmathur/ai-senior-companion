"""
Scam Shield Fraud Detection Service ("Check a Scam").
Analyzes suspicious SMS, emails, WhatsApp forwards, URLs, and screenshots for digital fraud patterns.
"""
import logging
import re
from typing import Optional
from PIL import Image
from models.analysis import ScamAnalysis
from prompts.scam_prompt import get_scam_prompt
from services.gemini_service import gemini_service

logger = logging.getLogger(__name__)


class ScamService:
    # High-risk patterns in Indian & global senior scams
    LOTTERY_PRIZE_PATTERN = re.compile(r'\b(won|winner|lottery|lucky draw|prize|lakh|crore|reward)\b', re.IGNORECASE)
    UPFRONT_FEE_PATTERN = re.compile(r'\b(processing fee|transfer fee|advance tax|clearance fee|pay rs|pay ₹)\b', re.IGNORECASE)
    URGENCY_THREAT_PATTERN = re.compile(r'\b(disconnected tonight|immediately|within 24 hours|suspended|blocked|terminated|urgent)\b', re.IGNORECASE)
    SENSITIVE_REQUEST_PATTERN = re.compile(r'\b(otp|pin|password|aadhaar|pan card|cvv|bank details)\b', re.IGNORECASE)
    SUSPICIOUS_LINK_PATTERN = re.compile(r'https?://[^\s/$.?#].[^\s]*|bit\.ly|tinyurl|t\.me', re.IGNORECASE)

    def analyze_scam(
        self,
        message_text: Optional[str] = None,
        image: Optional[Image.Image] = None,
        language: str = "English"
    ) -> ScamAnalysis:
        """
        Assesses scam threat level and returns structured ScamAnalysis.
        """
        is_hindi = language.lower() == "hindi"
        fallback_data = self._heuristic_analysis(message_text, is_hindi)

        prompt = get_scam_prompt(language=language)
        content_items = []
        if image:
            content_items.append(image)
        if message_text:
            prompt += f"\n\nMessage content to evaluate:\n{message_text}"

        if gemini_service.is_configured():
            try:
                parsed_json = gemini_service.generate_structured_json(
                    prompt=prompt,
                    content_items=content_items if content_items else None,
                    default_fallback=fallback_data
                )
                if parsed_json:
                    return ScamAnalysis(**parsed_json)
            except Exception as e:
                logger.error(f"Error calling Gemini for scam analysis: {e}")

        return ScamAnalysis(**fallback_data)

    def _heuristic_analysis(self, text: Optional[str], is_hindi: bool) -> dict:
        """High-precision heuristic evaluation for offline or fallback analysis."""
        content = (text or "").lower()

        is_lottery = bool(self.LOTTERY_PRIZE_PATTERN.search(content))
        has_fee = bool(self.UPFRONT_FEE_PATTERN.search(content))
        has_urgency = bool(self.URGENCY_THREAT_PATTERN.search(content))
        has_sensitive_ask = bool(self.SENSITIVE_REQUEST_PATTERN.search(content))
        has_link = bool(self.SUSPICIOUS_LINK_PATTERN.search(content))

        # Check for High Risk
        if (is_lottery and has_fee) or (has_urgency and (has_sensitive_ask or has_link)) or "claim" in content:
            if is_hindi:
                return {
                    "risk_level": "HIGH",
                    "summary": "यह संदेश धोखाधड़ी (Scam) से जुड़े कई गंभीर लक्षण दर्शाता है।",
                    "warning_signs": [
                        "इनाम या लॉटरी देने के नाम पर पहले पैसे (प्रोसेसिंग फीस) मांगे जा रहे हैं।",
                        "तुरंत पैसे देने या 24 घंटे में कनेक्शन काटने का झूठा डर पैदा किया जा रहा है।",
                        "संदेश किसी व्यक्तिगत मोबाइल नंबर या संदिग्ध लिंक से भेजा गया है, आधिकारिक बैंक या बिजली विभाग से नहीं।"
                    ],
                    "do_not_do": [
                        "अपना ओटीपी (OTP), पिन (PIN) या बैंक पासवर्ड कभी भी किसी को न बताएं।",
                        "कथित प्रोसेसिंग फीस या टैक्स के नाम पर कोई भी रुपया ट्रांसफर न करें।",
                        "संदेश में दिए गए किसी भी लिंक पर क्लिक न करें।"
                    ],
                    "safe_next_steps": [
                        "इस संदेश को तुरंत अनदेखा करें या ब्लॉक करें।",
                        "यदि कोई संदेह हो, तो अपने बेटे/बेटी या बैंक के आधिकारिक टोल-फ्री नंबर पर कॉल करके पुष्टि करें।"
                    ],
                    "confidence": "high"
                }
            return {
                "risk_level": "HIGH",
                "summary": "This message contains signs strongly associated with financial lottery or urgency fraud.",
                "warning_signs": [
                    "Promises an unexpected prize or lottery payout you never entered.",
                    "Demands an upfront 'processing fee' or 'clearance tax' before giving the money.",
                    "Creates intense artificial urgency threatening cancellation or service disconnection."
                ],
                "do_not_do": [
                    "NEVER share your OTP, PIN, password, or bank account credentials.",
                    "NEVER transfer processing fees or advance money.",
                    "Do NOT click on any link provided in this message."
                ],
                "safe_next_steps": [
                    "Ignore and block the sender.",
                    "If you are concerned about your account or bill, verify with your official bank or utility branch directly."
                ],
                "confidence": "high"
            }

        # Check for Medium Risk (general unsolicited links or account notices)
        if has_link or has_urgency or has_sensitive_ask:
            if is_hindi:
                return {
                    "risk_level": "MEDIUM",
                    "summary": "इस संदेश में कुछ ऐसे संकेत हैं जिनके लिए सावधानी बरतने की आवश्यकता है।",
                    "warning_signs": [
                        "संदेश में एक अज्ञात लिंक या तत्काल कार्रवाई करने का आग्रह किया गया है।",
                        "आधिकारिक प्रेषक पहचान की कमी है।"
                    ],
                    "do_not_do": [
                        "लिंक पर क्लिक न करें और न ही कोई ऐप डाउनलोड करें।",
                        "अपनी व्यक्तिगत जानकारी साझा न करें।"
                    ],
                    "safe_next_steps": [
                        "आधिकारिक ऐप या वेबसाइट खोलकर स्वतंत्र रूप से स्थिति की जाँच करें।"
                    ],
                    "confidence": "medium"
                }
            return {
                "risk_level": "MEDIUM",
                "summary": "This message contains cautionary indicators that require careful verification.",
                "warning_signs": [
                    "Contains an unverified web link or requests swift action.",
                    "Sender identity is not explicitly authenticated."
                ],
                "do_not_do": [
                    "Do not click links or install third-party APKs/apps.",
                    "Do not share personal verification codes."
                ],
                "safe_next_steps": [
                    "Check your account directly by visiting the official website or using your trusted app."
                ],
                "confidence": "medium"
            }

        # Low Risk
        if is_hindi:
            return {
                "risk_level": "LOW",
                "summary": "इस संदेश में धोखाधड़ी का कोई स्पष्ट या सामान्य संकेत नहीं मिला।",
                "warning_signs": [
                    "कोई तत्काल पैसे या गुप्त पासवर्ड की मांग नहीं की गई है।"
                ],
                "do_not_do": [
                    "सामान्य सावधानी बनाए रखें: ओटीपी या पासवर्ड कभी भी किसी के साथ साझा न करें।"
                ],
                "safe_next_steps": [
                    "यदि यह सामान्य जानकारी या सूचना है, तो आप निश्चिंत रह सकते हैं।"
                ],
                "confidence": "medium"
            }

        return {
            "risk_level": "LOW",
            "summary": "This message does not exhibit common characteristics of scam or fraud communications.",
            "warning_signs": [
                "No suspicious demand for money, secret credentials, or immediate panic."
            ],
            "do_not_do": [
                "Standard hygiene: Never disclose your banking PIN or OTP under any circumstance."
            ],
            "safe_next_steps": [
                "You may proceed normally with your regular activities."
            ],
            "confidence": "medium"
        }


scam_service = ScamService()
