"""
Safety and Guardrails Service for AI Senior Companion.
Ensures no sensitive data (OTPs, PINs, passwords) is leaked, provides disclaimers,
and maintains strict ethical boundaries for medical and financial domains.
"""
import re
from typing import Tuple, Optional


class SafetyService:
    # Patterns for sensitive credentials
    OTP_PATTERN = re.compile(r'\b(?:otp|one[- ]time[- ]password|code)\s*[:=is\s]*(\d{4,8})\b', re.IGNORECASE)
    CARD_PATTERN = re.compile(r'\b(?:\d[ -]*?){13,16}\b')
    CVV_PATTERN = re.compile(r'\b(?:cvv|cvc|security code)\s*[:=is\s]*(\d{3,4})\b', re.IGNORECASE)
    PIN_PATTERN = re.compile(r'\b(?:atm[- ]pin|mpin|upi[- ]pin|secret pin)\s*[:=is\s]*(\d{4,6})\b', re.IGNORECASE)

    # Topic trigger keywords
    MEDICAL_KEYWORDS = [
        "diagnosis", "cancer", "chest pain", "dose", "dosage", "symptoms", 
        "prescription", "tablet", "injection", "dr.", "doctor", "hospital",
        "blood pressure", "sugar level", "diabetes", "cardiac"
    ]
    FINANCIAL_KEYWORDS = [
        "transfer money", "investment", "stock market", "mutual fund", "bank account",
        "fixed deposit", "debit card", "credit card", "loan", "kyc update"
    ]

    @classmethod
    def sanitize_user_input(cls, text: str) -> Tuple[str, bool]:
        """
        Sanitizes user input by masking OTPs, card numbers, or PINs.
        Returns: (sanitized_text, was_sensitive_detected)
        """
        detected = False
        sanitized = text

        if cls.OTP_PATTERN.search(sanitized):
            sanitized = cls.OTP_PATTERN.sub("[SENSITIVE OTP HIDDEN FOR YOUR SAFETY]", sanitized)
            detected = True

        if cls.CARD_PATTERN.search(sanitized):
            sanitized = cls.CARD_PATTERN.sub("[CARD NUMBER HIDDEN FOR YOUR SAFETY]", sanitized)
            detected = True

        if cls.CVV_PATTERN.search(sanitized):
            sanitized = cls.CVV_PATTERN.sub("[CVV HIDDEN FOR YOUR SAFETY]", sanitized)
            detected = True

        if cls.PIN_PATTERN.search(sanitized):
            sanitized = cls.PIN_PATTERN.sub("[SECRET PIN HIDDEN FOR YOUR SAFETY]", sanitized)
            detected = True

        return sanitized, detected

    @classmethod
    def get_domain_disclaimer(cls, text: str, language: str = "English") -> Optional[str]:
        """
        Returns relevant domain safety notice for medical or financial inquiries.
        """
        lower = text.lower()
        is_hindi = language.lower() == "hindi"

        # Medical Check
        if any(kw in lower for kw in cls.MEDICAL_KEYWORDS):
            if is_hindi:
                return "🩺 स्वास्थ्य सूचना: मैं आपको जानकारी सरल शब्दों में समझा सकता हूँ, लेकिन कोई चिकित्सीय निदान या इलाज नहीं बता सकता। कृपया अपने डॉक्टर की सलाह अवश्य लें।"
            return "🩺 Medical Notice: I can help explain the information, but I cannot diagnose a medical condition or prescribe treatment. Please consult your doctor."

        # Financial Check
        if any(kw in lower for kw in cls.FINANCIAL_KEYWORDS):
            if is_hindi:
                return "💰 वित्तीय सुरक्षा: मैं केवल मार्गदर्शन और स्पष्टीकरण देता हूँ। मैं कभी भी आपका पासवर्ड, पिन या ओटीपी नहीं मांगता और न ही कोई भुगतान करता हूँ।"
            return "💰 Financial Safety: I provide educational guidance only. I will never ask for your banking PIN or OTP, and I cannot make payments on your behalf."

        return None
