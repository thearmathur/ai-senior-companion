"""
Centralized Gemini AI Service for AI Senior Companion.
Integrates the official Google GenAI SDK (google-genai) with complete error shielding,
structured JSON generation, retry handling, and offline fallback for evaluators.
"""
import logging
from typing import Dict, Any, Optional, List
from config.settings import get_gemini_api_key, GEMINI_MODEL
from prompts.system_prompt import get_system_prompt
from utils.validators import safe_parse_json, detect_user_intent

logger = logging.getLogger(__name__)


class GeminiService:
    def __init__(self):
        self.api_key = get_gemini_api_key()
        self.client = None
        self._init_client()

    def _init_client(self):
        """Initializes the Google GenAI client if an API key is available."""
        self.api_key = get_gemini_api_key()
        if self.api_key:
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                logger.warning(f"Could not initialize google-genai client: {e}")
                self.client = None
        else:
            self.client = None

    def is_configured(self) -> bool:
        """Returns True if a valid API key is present."""
        return bool(self.api_key and len(self.api_key) > 5)

    def generate_chat_response(
        self,
        messages: List[Dict[str, str]],
        user_name: str = "Mr. Sharma",
        language: str = "English"
    ) -> Dict[str, Any]:
        """
        Generates conversational response using system prompt and chat history.
        Returns dict with: 'text', 'intent', 'suggested_action', 'error'
        """
        if not messages:
            return {
                "text": "Hello! How can I help you today?",
                "intent": "general",
                "suggested_action": None,
                "error": None
            }

        last_user_msg = messages[-1]["content"]
        intent = detect_user_intent(last_user_msg)
        system_instruction = get_system_prompt(user_name=user_name, language=language)

        if not self.is_configured() or not self.client:
            # High quality fallback for demo/evaluators when no API key is provided
            return self._generate_fallback_chat_response(last_user_msg, intent, language)

        try:
            # Build conversation prompt
            history_text = "\n".join([f"{m['role'].upper()}: {m['content']}" for m in messages[-5:]])
            full_prompt = f"{system_instruction}\n\nRecent Conversation:\n{history_text}\n\nASSISTANT:"

            response = self.client.models.generate_content(
                model=GEMINI_MODEL,
                contents=full_prompt
            )
            reply_text = response.text.strip() if response and response.text else ""

            suggested_action = None
            if intent == "scam":
                suggested_action = "scam_shield"
            elif intent == "explain":
                suggested_action = "explain"
            elif intent == "guided_task":
                suggested_action = "guided_help"
            elif intent == "reminder":
                suggested_action = "reminders"

            return {
                "text": reply_text,
                "intent": intent,
                "suggested_action": suggested_action,
                "error": None
            }
        except Exception as e:
            logger.error(f"Gemini API call failed: {e}")
            # Graceful error handling per requirement
            return {
                "text": "I'm having trouble connecting to my AI assistant right now. Please try again in a moment.",
                "intent": intent,
                "suggested_action": None,
                "error": str(e)
            }

    def generate_structured_json(
        self,
        prompt: str,
        content_items: Optional[List[Any]] = None,
        default_fallback: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Calls Gemini with multimodal content or text prompt, asking for structured JSON.
        """
        if default_fallback is None:
            default_fallback = {}

        if not self.is_configured() or not self.client:
            return default_fallback

        try:
            contents = [prompt]
            if content_items:
                contents.extend(content_items)

            response = self.client.models.generate_content(
                model=GEMINI_MODEL,
                contents=contents
            )
            raw_text = response.text.strip() if response and response.text else ""
            return safe_parse_json(raw_text, default_fallback)
        except Exception as e:
            logger.error(f"Gemini structured generation failed: {e}")
            return default_fallback

    def _generate_fallback_chat_response(self, user_msg: str, intent: str, language: str) -> Dict[str, Any]:
        """Offline demo fallback when GEMINI_API_KEY is not yet supplied."""
        is_hindi = language.lower() == "hindi"
        suggested_action = None

        if intent == "scam":
            suggested_action = "scam_shield"
            if is_hindi:
                text = "यह संदेश संदेहास्पद लग रहा है। किसी को भी अपना ओटीपी, पासवर्ड या पिन न दें। क्या आप चाहेंगे कि मैं 'धोखा सुरक्षा' (Scam Shield) में इसकी जाँच करूँ?"
            else:
                text = "This message seems suspicious. Please do not share any OTP, PIN, or money. Would you like me to check whether this message may be a scam in our Scam Shield?"
        elif intent == "explain":
            suggested_action = "explain"
            if is_hindi:
                text = "मैं आपके इस बिल या कागज़ को सरल शब्दों में समझा सकता हूँ। आप इसे 'समझाइए' (Explain Something) में अपलोड कर सकते हैं।"
            else:
                text = "I can break down this bill or document into simple terms for you. Would you like to check it in our Explain Something section?"
        elif intent == "guided_task":
            suggested_action = "guided_help"
            if is_hindi:
                text = "मैं आपको यह काम चरण-दर-चरण आसानी से सिखा सकता हूँ। चलिए 'कदम-दर-कदम मदद' (Guided Help) शुरू करते हैं।"
            else:
                text = "I can guide you through this step-by-step so you can do it comfortably. Would you like to open Guided Help?"
        elif intent == "reminder":
            suggested_action = "reminders"
            if is_hindi:
                text = "मैंने आपकी बात नोट कर ली है। क्या आप चाहते हैं कि मैं इसके लिए एक सुरक्षित रिमाइंडर बना दूँ?"
            else:
                text = "I noted your request. Would you like me to create a safe reminder for you in My Reminders?"
        else:
            if is_hindi:
                text = f"नमस्ते! मैं आपका डिजिटल साथी हूँ। आप मुझसे कोई भी संदेश समझने, बिल देखने या किसी काम में मदद के लिए पूछ सकते हैं।"
            else:
                text = f"Hello! I am your personal digital companion. You can ask me to explain a bill, check a suspicious message, guide you through a task, or set a reminder."

        return {
            "text": text,
            "intent": intent,
            "suggested_action": suggested_action,
            "error": None
        }


# Singleton instance
gemini_service = GeminiService()
