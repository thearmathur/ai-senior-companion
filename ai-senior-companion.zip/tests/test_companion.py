"""
Comprehensive Test Suite for AI Senior Companion.
Covers:
1. Database initialization and CRUD operations
2. Gemini configuration and graceful fallback
3. Scam detection workflow (lottery, urgency, sensitive info)
4. Document explanation workflow (bills, charges, due dates)
5. Natural language reminder parsing (English & Hindi)
6. Guided help step sequencing
7. Safety service guardrails (OTP masking, medical/financial disclaimers)
8. Accessibility styling and CSS generation
9. Multilingual localization
"""
import os
import pytest
from datetime import datetime, timedelta

from database.database import (
    init_db,
    seed_demo_data,
    reset_demo_data,
    get_default_user,
    get_user_preferences,
    update_user_preferences,
    add_reminder,
    get_reminders,
    update_reminder_status,
    delete_reminder,
    get_trusted_contacts,
    add_trusted_contact
)
from services.gemini_service import GeminiService
from services.scam_service import scam_service
from services.document_service import document_service
from services.reminder_service import reminder_service
from services.guided_service import guided_service
from services.safety_service import SafetyService
from utils.accessibility import get_accessibility_css
from utils.helpers import t, format_friendly_date, get_greeting
from utils.validators import clean_json_markdown, safe_parse_json, detect_user_intent


@pytest.fixture(autouse=True)
def setup_fresh_db():
    """Ensures each test operates on clean seeded demo database."""
    reset_demo_data()
    yield


# --- 1. DATABASE & PERSISTENCE TESTS ---
def test_database_initialization_and_seed():
    user = get_default_user()
    assert user is not None
    assert user["name"] == "Mr. Sharma"

    prefs = get_user_preferences(user["id"])
    assert prefs["text_size"] == "Large"
    assert prefs["language"] == "English"

    reminders = get_reminders(user["id"])
    assert len(reminders) >= 3


def test_reminder_crud():
    user = get_default_user()
    rem_id = add_reminder(
        user_id=user["id"],
        title="Eye Drops (Carboxymethylcellulose)",
        category="Medicine",
        due_date="2026-09-25",
        due_time="14:00",
        notes="Put 2 drops in both eyes"
    )
    assert rem_id > 0

    rems = get_reminders(user["id"])
    titles = [r["title"] for r in rems]
    assert "Eye Drops (Carboxymethylcellulose)" in titles

    # Update status
    update_reminder_status(rem_id, "COMPLETED")
    completed = get_reminders(user["id"], status_filter="COMPLETED")
    assert any(r["id"] == rem_id for r in completed)

    # Delete
    delete_reminder(rem_id)
    remaining = get_reminders(user["id"])
    assert not any(r["id"] == rem_id for r in remaining)


def test_user_preferences_update():
    user = get_default_user()
    update_user_preferences(user["id"], "Extra Large", "High Contrast", "Hindi", 1)
    prefs = get_user_preferences(user["id"])
    assert prefs["text_size"] == "Extra Large"
    assert prefs["contrast_mode"] == "High Contrast"
    assert prefs["language"] == "Hindi"


# --- 2. GEMINI SERVICE & FALLBACK TESTS ---
def test_gemini_service_offline_resilience():
    service = GeminiService()
    # Test chat generation without API key or network failure
    chat_res = service.generate_chat_response(
        [{"role": "user", "content": "I received a suspicious message about winning money"}],
        user_name="Mr. Sharma",
        language="English"
    )
    assert chat_res is not None
    assert "text" in chat_res
    assert len(chat_res["text"]) > 10
    assert chat_res["intent"] == "scam"
    assert chat_res["suggested_action"] == "scam_shield"


# --- 3. SCAM SHIELD WORKFLOW TESTS ---
def test_scam_lottery_high_risk():
    text = "Congratulations! You have won ₹25 lakh. Pay ₹5,000 processing fee to claim your prize."
    analysis = scam_service.analyze_scam(message_text=text, language="English")
    assert analysis.risk_level == "HIGH"
    assert len(analysis.warning_signs) > 0
    assert any("otp" in d.lower() or "fee" in d.lower() for d in analysis.do_not_do)
    assert len(analysis.safe_next_steps) > 0


def test_scam_electricity_disconnection_high_risk():
    text = "URGENT: Your electricity connection will be disconnected tonight at 9:30 PM. Call 9123456789 to update bill."
    analysis = scam_service.analyze_scam(message_text=text, language="English")
    assert analysis.risk_level in ["HIGH", "MEDIUM"]
    assert len(analysis.warning_signs) > 0


def test_scam_benign_message_low_risk():
    text = "Dear Anand, your appointment with Dr. Verma is confirmed for tomorrow at 11 AM."
    analysis = scam_service.analyze_scam(message_text=text, language="English")
    assert analysis.risk_level in ["LOW", "MEDIUM"]


# --- 4. DOCUMENT EXPLANATION WORKFLOW TESTS ---
def test_explain_electricity_bill():
    text = """
    BSES RAJDHANI POWER LIMITED
    Consumer No: 100458921
    Amount Payable: ₹2,450
    Due Date: 25-Sep-2026
    Units: 340 Units
    """
    explanation = document_service.explain_content(text_content=text, language="English")
    assert "electricity" in explanation.document_type.lower() or "bill" in explanation.document_type.lower()
    assert explanation.amount_to_pay is not None
    assert "2,450" in explanation.amount_to_pay
    assert len(explanation.important_details) > 0
    assert len(explanation.what_you_need_to_do) > 0


# --- 5. REMINDER PARSING TESTS (NLP & MULTILINGUAL) ---
def test_reminder_extraction_english():
    text = "Remind me tomorrow at 10 AM to call my doctor"
    extracted = reminder_service.extract_reminder(text, language="English")
    assert "doctor" in extracted.title.lower()
    assert extracted.category == "Appointments"
    assert extracted.time in ["10:00", "09:00"]
    tomorrow_str = (datetime.now().date() + timedelta(days=1)).strftime("%Y-%m-%d")
    assert extracted.date == tomorrow_str


def test_reminder_extraction_hindi():
    text = "मुझे कल डॉक्टर को कॉल करना है"
    extracted = reminder_service.extract_reminder(text, language="Hindi")
    assert extracted.category == "Appointments"
    tomorrow_str = (datetime.now().date() + timedelta(days=1)).strftime("%Y-%m-%d")
    assert extracted.date == tomorrow_str


def test_daily_medicine_reminder():
    text = "Remind me every morning at 9 to take my medicine"
    extracted = reminder_service.extract_reminder(text, language="English")
    assert extracted.category == "Medicine"
    assert extracted.recurrence == "Daily"
    assert extracted.time == "09:00"


# --- 6. GUIDED TASK WORKFLOW TESTS ---
def test_guided_help_task_steps():
    task = guided_service.get_task("Pay an electricity bill", language="English")
    assert task.total_steps == 4
    assert len(task.steps) == 4
    assert "Consumer Number" in task.steps[0].title
    assert task.steps[0].action_button_label == "I've Done This ->"
    assert task.steps[-1].action_button_label == "Finish Task"
    assert "No actual" in task.disclaimer


def test_guided_help_hindi():
    task = guided_service.get_task("Pay an electricity bill", language="Hindi")
    assert len(task.steps) == 4
    assert "बिजली" in task.task_name


# --- 7. SAFETY & GUARDRAILS TESTS ---
def test_safety_otp_redaction():
    text = "My secret bank OTP is 492810. Please help me enter it."
    sanitized, detected = SafetyService.sanitize_user_input(text)
    assert detected is True
    assert "492810" not in sanitized
    assert "[SENSITIVE OTP HIDDEN FOR YOUR SAFETY]" in sanitized


def test_safety_medical_disclaimer():
    text = "What is the diagnosis and dosage for chest pain?"
    disclaimer = SafetyService.get_domain_disclaimer(text, language="English")
    assert disclaimer is not None
    assert "Medical Notice" in disclaimer
    assert "cannot diagnose" in disclaimer


def test_safety_financial_disclaimer():
    text = "How do I transfer money from my bank account?"
    disclaimer = SafetyService.get_domain_disclaimer(text, language="English")
    assert disclaimer is not None
    assert "Financial Safety" in disclaimer


# --- 8. ACCESSIBILITY & LOCALIZATION TESTS ---
def test_accessibility_css_scaling():
    css_standard = get_accessibility_css(text_size="Standard", contrast_mode="Standard")
    css_xlarge = get_accessibility_css(text_size="Extra Large", contrast_mode="High Contrast")

    assert "18px" in css_standard
    assert "26px" in css_xlarge
    assert "#0B0F19" in css_xlarge  # High contrast background
    assert "#FACC15" in css_xlarge  # High contrast yellow accent


def test_localization_dictionary():
    assert t("nav_home", "English") == "🏠 Home"
    assert "मुख्य पृष्ठ" in t("nav_home", "Hindi")
    assert "सुप्रभात" in get_greeting("Mr. Sharma", "Hindi")


# --- 9. VALIDATORS & INTENT DETECTION ---
def test_json_cleaners_and_intent():
    fenced = "```json\n{\"risk_level\": \"HIGH\"}\n```"
    assert clean_json_markdown(fenced) == "{\"risk_level\": \"HIGH\"}"
    parsed = safe_parse_json(fenced)
    assert parsed["risk_level"] == "HIGH"

    assert detect_user_intent("I received a fake lottery message") == "scam"
    assert detect_user_intent("Explain my electricity bill") == "explain"
    assert detect_user_intent("How do I book a doctor appointment") == "guided_task"
    assert detect_user_intent("Remind me to take my pills tomorrow") == "reminder"


# --- 10. EDGE CASE TESTS ---
def test_empty_and_invalid_inputs():
    # Empty chat input
    service = GeminiService()
    empty_res = service.generate_chat_response([])
    assert "Hello" in empty_res["text"]

    # Empty scam input
    empty_scam = scam_service.analyze_scam(message_text="")
    assert empty_scam.risk_level in ["LOW", "UNKNOWN"]

    # Empty document input
    empty_doc = document_service.explain_content(text_content="")
    assert empty_doc.document_type is not None

    # Corrupted / non-JSON string
    bad_json = safe_parse_json("This is not JSON at all!", default={"status": "fallback"})
    assert bad_json["status"] == "fallback"


def test_database_reset_and_integrity():
    user = get_default_user()
    assert user["name"] == "Mr. Sharma"
    # Seed a custom contact
    cid = add_trusted_contact(user["id"], "Kavita Sharma", "Daughter", "+91 99999 88888")
    assert cid > 0
    # Reset
    reset_demo_data()
    fresh_user = get_default_user()
    assert fresh_user["name"] == "Mr. Sharma"
    contacts = get_trusted_contacts(fresh_user["id"])
    assert len(contacts) == 1
    assert contacts[0]["name"] == "Aarav Sharma"

